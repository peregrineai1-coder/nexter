import { motion } from "framer-motion";
import { Zap, Shield, Heart } from "lucide-react";

const values = [
  { icon: Zap, title: "Creative", text: "Bold ideas that make your brand unforgettable." },
  { icon: Shield, title: "Reliable", text: "Consistent quality you can always count on." },
  { icon: Heart, title: "Dedicated", text: "Your success is our mission, every single time." },
];

const About = () => {
  return (
    <section id="about" className="py-24 md:py-32 bg-card">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-primary text-sm font-medium tracking-widest uppercase">About Us</span>
            <h2 className="font-display text-3xl md:text-5xl font-bold mt-3 mb-6">
              Why Choose <span className="gradient-text">Nexter</span>?
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-4">
              We provide creative, reliable, and professional digital solutions that help businesses stand out, build trust, and grow online.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Whether you're a startup launching your first product or an established business looking to refresh your brand — we've got you covered.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="flex flex-col gap-5"
          >
            {values.map((v) => (
              <div key={v.title} className="flex gap-4 items-start bg-background border border-border rounded-xl p-6">
                <div className="w-10 h-10 rounded-lg gradient-bg flex items-center justify-center shrink-0">
                  <v.icon size={18} className="text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-display font-semibold text-lg mb-1">{v.title}</h3>
                  <p className="text-muted-foreground text-sm">{v.text}</p>
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;

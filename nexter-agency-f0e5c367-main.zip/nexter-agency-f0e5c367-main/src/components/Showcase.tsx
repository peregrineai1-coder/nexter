import { ContainerScroll } from "@/components/ui/container-scroll-animation";

const Showcase = () => {
  return (
    <section className="bg-background overflow-hidden">
      <ContainerScroll
        titleComponent={
          <div className="flex flex-col items-center">
            <span className="text-primary text-sm font-medium tracking-widest uppercase mb-3">
              Our Work
            </span>
            <h2 className="font-display text-3xl md:text-5xl lg:text-6xl font-bold">
              Crafted with <span className="gradient-text">Precision</span>
            </h2>
            <p className="text-muted-foreground text-lg mt-4 max-w-lg mx-auto">
              From concept to launch, we deliver digital experiences that stand out.
            </p>
          </div>
        }
      >
        <img
          src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2426&auto=format&fit=crop"
          alt="Nexter agency showcase - professional digital solutions"
          className="w-full h-full object-cover object-left-top rounded-lg"
          loading="lazy"
          draggable={false}
        />
      </ContainerScroll>
    </section>
  );
};

export default Showcase;

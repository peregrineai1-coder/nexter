import { motion } from "framer-motion";
import { Palette, Globe, ShoppingBag, Box } from "lucide-react";

const services = [
{
  icon: Palette,
  title: "Logo & Brand Identity",
  description: "Unique, memorable logos and complete brand identities that make your business instantly recognizable.",
  gradient: "bg-gradient-to-br from-violet-500 to-indigo-600"
},
{
  icon: Globe,
  title: "Website & Landing Pages",
  description: "Professional websites designed to engage visitors, tell your story, and convert them into customers.",
  gradient: "bg-gradient-to-br from-blue-500 to-cyan-500"
},
{
  icon: ShoppingBag,
  title: "E-commerce Stores",
  description: "Fully functional online stores built to sell — from product pages to checkout, ready to grow your revenue.",
  gradient: "bg-gradient-to-br from-emerald-500 to-teal-500"
},
{
  icon: Box,
  title: "Product Mockups",
  description: "High-quality product visuals for presentations, marketing campaigns, and social media content.",
  gradient: "bg-gradient-to-br from-rose-500 to-pink-500"
}];


const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12 } }
};

const item = {
  hidden: { opacity: 0, y: 30 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" as const } }
};

const Services = () => {
  const scrollTo = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="services" className="py-24 md:py-32">
      <div className="container mx-auto px-4 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16">

          <span className="text-primary text-sm font-medium tracking-widest uppercase">What We Do</span>
          <h2 className="font-display text-3xl md:text-5xl font-bold mt-3">Our Services</h2>
        </motion.div>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6">

          {services.map((s) =>
          <motion.div
            key={s.title}
            variants={item}
            className="group bg-card border border-border rounded-xl p-8 hover:border-primary/30 hover:glow-border transition-all duration-300 cursor-pointer"
            onClick={() => scrollTo("#contact")}>

              <div className={`w-12 h-12 rounded-xl ${s.gradient} flex items-center justify-center mb-5 shadow-lg`}>
                <s.icon size={22} className="text-white" />
              </div>
              <h3 className="font-display text-xl font-semibold mb-3">{s.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{s.description}</p>
            </motion.div>
          )}
        </motion.div>
      </div>
    </section>);

};

export default Services;
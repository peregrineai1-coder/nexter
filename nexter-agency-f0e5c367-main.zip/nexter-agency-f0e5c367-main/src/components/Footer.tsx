import nexterLogo from "@/assets/nexter-logo.png";
import { Instagram, MessageCircle } from "lucide-react";

const socials = [
  {
    label: "Instagram",
    href: "https://www.instagram.com/nexter.agency/?hl=en",
    icon: Instagram,
  },
  {
    label: "TikTok",
    href: "https://www.tiktok.com/@nexter.agency?is_from_webapp=1&sender_device=pc",
    icon: () => (
      <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
        <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.34-6.34V8.75a8.18 8.18 0 004.76 1.52V6.84a4.84 4.84 0 01-1-.15z" />
      </svg>
    ),
  },
  {
    label: "WhatsApp",
    href: "https://wa.link/zwt5ta",
    icon: MessageCircle,
  },
];

const Footer = () => {
  const scrollTo = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="border-t border-border py-12">
      <div className="container mx-auto px-4 md:px-8 flex flex-col items-center gap-8">
        <button onClick={() => scrollTo("#hero")}>
          <img src={nexterLogo} alt="Nexter" className="h-8" />
        </button>

        <div className="flex gap-6">
          {["Services", "About", "Contact"].map((l) => (
            <button
              key={l}
              onClick={() => scrollTo(`#${l.toLowerCase()}`)}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              {l}
            </button>
          ))}
        </div>

        <div className="flex gap-4">
          {socials.map((s) => (
            <a
              key={s.label}
              href={s.href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={s.label}
              className="group w-10 h-10 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-primary-foreground hover:bg-primary hover:border-primary transition-all duration-300 hover:scale-110 hover:shadow-lg"
            >
              <s.icon size={18} />
            </a>
          ))}
        </div>

        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} Nexter. All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;

import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import nexterLogo from "@/assets/nexter-logo.png";
import { WebGLShader } from "@/components/ui/web-gl-shader";
import { LiquidButton } from "@/components/ui/liquid-glass-button";

const Hero = () => {
  const scrollTo = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* WebGL Shader Background */}
      <div className="absolute inset-0 opacity-40">
        <WebGLShader />
      </div>
      {/* Overlay gradient for readability */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />

      <div className="relative z-10 container mx-auto px-4 md:px-8 pt-24 pb-16 text-center">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
        >
          <motion.img
            src={nexterLogo}
            alt="Nexter - We Build, You Grow"
            className="mx-auto mb-10 h-28 md:h-40 lg:h-48"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          />
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold leading-[1.05] mb-6">
            We Build,
            <br />
            <span className="gradient-text">You Grow</span>
          </h1>
          <p className="text-muted-foreground text-lg md:text-xl max-w-xl mx-auto mb-10 leading-relaxed">
            Professional branding & digital solutions that help your business stand out, build trust, and grow online.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <LiquidButton
              size="xl"
              onClick={() => scrollTo("#contact")}
              className="text-foreground font-semibold"
            >
              Start a Project <ArrowRight size={18} />
            </LiquidButton>
            <button
              onClick={() => scrollTo("#services")}
              className="border border-border text-foreground font-medium px-8 py-3.5 rounded-lg hover:bg-secondary transition-colors"
            >
              Our Services
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;

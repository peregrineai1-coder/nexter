import { motion, useScroll, useTransform } from "framer-motion";
import { useRef, useState } from "react";
import { ArrowUpRight, ExternalLink, Eye, Sparkles, Layers, Globe, ShoppingBag, Palette } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import SEOHead from "@/components/SEOHead";

const projects = [
  {
    id: "zeicorp",
    title: "ZeiCorp Services",
    category: "Cleaning Business",
    tagline: "Professional cleaning you can trust",
    description:
      "Complete brand identity and website for a professional cleaning company. Designed to build trust instantly with warm tones, real testimonials, and a direct call-to-action flow that converts visitors into booked appointments.",
    image: "/projects/zeicorp.png",
    url: "https://zeicorp.lovable.app",
    services: ["Brand Identity", "Website Design", "SEO"],
    stats: [
      { label: "Conversion Rate", value: "3.2×" },
      { label: "Load Speed", value: "<1s" },
      { label: "Mobile Score", value: "98" },
    ],
    accentGradient: "from-teal-500 to-cyan-400",
    accentColor: "hsl(180, 60%, 50%)",
  },
  {
    id: "athletic-minds",
    title: "Athletic Minds",
    category: "Fitness & Gym",
    tagline: "Where results-driven coaching meets an unmatched atmosphere",
    description:
      "A bold, high-energy digital presence for a premium gym in Beirut. Dark aesthetic with neon-green accents that mirror the gym's intense atmosphere. Built for engagement — Google reviews integration, service breakdowns, and location-driven CTAs.",
    image: "/projects/athletic-minds.png",
    url: "https://athletic-minds-pro.lovable.app",
    services: ["Website Design", "Brand Strategy", "Content"],
    stats: [
      { label: "Google Rating", value: "5.0★" },
      { label: "Engagement", value: "+140%" },
      { label: "Bounce Rate", value: "-45%" },
    ],
    accentGradient: "from-lime-500 to-emerald-500",
    accentColor: "hsl(100, 70%, 50%)",
  },
];

const ProjectCard = ({ project, index }: { project: typeof projects[0]; index: number }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);

  const { scrollYProgress } = useScroll({
    target: cardRef,
    offset: ["start end", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], [80, -80]);
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0.95, 1, 1, 0.95]);

  const isReversed = index % 2 !== 0;

  return (
    <motion.div
      ref={cardRef}
      style={{ opacity, scale }}
      className="relative"
    >
      {/* Ambient glow */}
      <div
        className="absolute -inset-px rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-700 blur-xl"
        style={{ background: `radial-gradient(600px circle at center, ${project.accentColor}15, transparent 70%)` }}
      />

      <div
        className={`relative grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-center ${isReversed ? "lg:direction-rtl" : ""}`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Image Side */}
        <motion.div
          style={{ y }}
          className={`relative group ${isReversed ? "lg:order-2" : ""}`}
        >
          <div className="relative overflow-hidden rounded-xl border border-border bg-card">
            {/* Browser chrome */}
            <div className="flex items-center gap-2 px-4 py-3 border-b border-border bg-secondary/50">
              <div className="flex gap-1.5">
                <span className="w-3 h-3 rounded-full bg-destructive/60" />
                <span className="w-3 h-3 rounded-full bg-muted-foreground/30" />
                <span className="w-3 h-3 rounded-full bg-muted-foreground/30" />
              </div>
              <div className="flex-1 flex justify-center">
                <span className="text-xs text-muted-foreground bg-secondary px-3 py-1 rounded-md font-mono truncate max-w-[200px]">
                  {project.url.replace("https://", "")}
                </span>
              </div>
            </div>

            {/* Screenshot */}
            <div className="relative overflow-hidden">
              <motion.img
                src={project.image}
                alt={`${project.title} - ${project.category} website by Nexter`}
                className="w-full h-auto"
                loading="lazy"
                animate={{ scale: isHovered ? 1.03 : 1 }}
                transition={{ duration: 0.6, ease: "easeOut" }}
              />
              {/* Hover overlay */}
              <motion.div
                className="absolute inset-0 flex items-center justify-center bg-background/60 backdrop-blur-sm"
                initial={{ opacity: 0 }}
                animate={{ opacity: isHovered ? 1 : 0 }}
                transition={{ duration: 0.3 }}
              >
                <a
                  href={project.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`flex items-center gap-2 px-6 py-3 rounded-lg bg-gradient-to-r ${project.accentGradient} text-background font-semibold text-sm transition-transform hover:scale-105`}
                >
                  <Eye size={16} /> View Live Site
                </a>
              </motion.div>
            </div>
          </div>
        </motion.div>

        {/* Content Side */}
        <div className={`space-y-6 ${isReversed ? "lg:order-1 lg:text-right" : ""}`}>
          <div>
            <motion.span
              className={`inline-block text-xs font-semibold tracking-widest uppercase bg-gradient-to-r ${project.accentGradient} bg-clip-text text-transparent mb-2`}
            >
              {project.category}
            </motion.span>
            <h3 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-3">
              {project.title}
            </h3>
            <p className="text-lg text-muted-foreground italic">"{project.tagline}"</p>
          </div>

          <p className="text-muted-foreground leading-relaxed">{project.description}</p>

          {/* Services tags */}
          <div className={`flex flex-wrap gap-2 ${isReversed ? "lg:justify-end" : ""}`}>
            {project.services.map((s) => (
              <span
                key={s}
                className="text-xs font-medium px-3 py-1.5 rounded-full border border-border bg-secondary/50 text-muted-foreground"
              >
                {s}
              </span>
            ))}
          </div>

          {/* Stats */}
          <div className={`grid grid-cols-3 gap-4 pt-4 border-t border-border ${isReversed ? "" : ""}`}>
            {project.stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className={`text-xl md:text-2xl font-bold bg-gradient-to-r ${project.accentGradient} bg-clip-text text-transparent`}>
                  {stat.value}
                </div>
                <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* CTA */}
          <a
            href={project.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-sm font-medium text-foreground hover:text-primary transition-colors group/link"
          >
            Visit Project <ArrowUpRight size={16} className="transition-transform group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5" />
          </a>
        </div>
      </div>
    </motion.div>
  );
};

const Portfolio = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  });
  const heroY = useTransform(scrollYProgress, [0, 1], [0, 150]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <SEOHead
        title="Portfolio | Nexter Digital Agency — Web Design & Branding Projects"
        description="See real results from Nexter's web design and branding projects. From cleaning businesses to fitness brands, we build websites that convert visitors into customers."
        canonical="https://nexter-agency.lovable.app/portfolio"
      />
      <Navbar />
      <section ref={heroRef} className="relative min-h-[80vh] flex items-center justify-center overflow-hidden pt-16">
        {/* Animated grid background */}
        <div className="absolute inset-0 opacity-[0.04]">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage:
                "linear-gradient(hsl(var(--foreground)) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--foreground)) 1px, transparent 1px)",
              backgroundSize: "60px 60px",
            }}
          />
        </div>

        {/* Floating orbs */}
        <motion.div
          className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-[120px] opacity-20"
          style={{ background: "hsl(var(--gradient-start))" }}
          animate={{ x: [0, 30, 0], y: [0, -20, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full blur-[100px] opacity-15"
          style={{ background: "hsl(var(--gradient-end))" }}
          animate={{ x: [0, -25, 0], y: [0, 25, 0] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        />

        <motion.div style={{ y: heroY, opacity: heroOpacity }} className="relative z-10 container mx-auto px-4 md:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-muted-foreground mb-6 border border-border px-4 py-2 rounded-full bg-secondary/30 backdrop-blur-sm">
              <Sparkles size={14} className="text-primary" /> Selected Work
            </div>
            <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold leading-[1.05] mb-6">
              Projects That
              <br />
              <span className="gradient-text">Deliver Results</span>
            </h1>
            <p className="text-muted-foreground text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
              Real businesses. Real growth. Every project is crafted to solve specific problems and drive measurable outcomes.
            </p>
          </motion.div>

          {/* Scroll indicator */}
          <motion.div
            className="mt-16"
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <div className="w-6 h-10 border-2 border-muted-foreground/30 rounded-full mx-auto flex justify-center pt-2">
              <motion.div
                className="w-1.5 h-1.5 rounded-full bg-muted-foreground"
                animate={{ y: [0, 12, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
            </div>
          </motion.div>
        </motion.div>
      </section>

      {/* Projects */}
      <section className="py-24 md:py-32">
        <div className="container mx-auto px-4 md:px-8 space-y-32 md:space-y-48">
          {projects.map((project, i) => (
            <ProjectCard key={project.id} project={project} index={i} />
          ))}
        </div>
      </section>

      {/* Process / What We Bring */}
      <section className="py-24 md:py-32 border-t border-border">
        <div className="container mx-auto px-4 md:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <span className="text-primary text-sm font-medium tracking-widest uppercase">Our Approach</span>
            <h2 className="font-display text-3xl md:text-5xl font-bold mt-3">
              What Every Project <span className="gradient-text">Gets</span>
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Palette, title: "Custom Design", desc: "No templates. Every pixel is intentional and tailored to your brand." },
              { icon: Globe, title: "SEO Built-In", desc: "Optimized from day one so your customers can actually find you." },
              { icon: Layers, title: "Mobile-First", desc: "Flawless on every device — phones, tablets, and desktops." },
              { icon: ShoppingBag, title: "Conversion Focus", desc: "Designed to turn visitors into paying customers, not just look pretty." },
            ].map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                className="group bg-card border border-border rounded-xl p-8 hover:border-primary/30 hover:glow-border transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl gradient-bg flex items-center justify-center mb-5 shadow-lg">
                  <item.icon size={22} className="text-background" />
                </div>
                <h3 className="font-display text-lg font-semibold mb-2 text-foreground">{item.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 md:py-32">
        <div className="container mx-auto px-4 md:px-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative overflow-hidden rounded-2xl border border-border bg-card p-12 md:p-20 text-center"
          >
            <div className="absolute inset-0 opacity-10 gradient-bg" />
            <div className="relative z-10">
              <h2 className="font-display text-3xl md:text-5xl font-bold mb-4">
                Ready to Be <span className="gradient-text">Next</span>?
              </h2>
              <p className="text-muted-foreground text-lg max-w-lg mx-auto mb-8">
                Your project could be the next case study. Let's build something that gets results.
              </p>
              <a
                href="/#contact"
                className="inline-flex items-center gap-2 bg-primary text-primary-foreground font-semibold px-8 py-4 rounded-lg hover:opacity-90 transition-opacity text-sm"
              >
                Start Your Project <ArrowUpRight size={16} />
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
};

export default Portfolio;
